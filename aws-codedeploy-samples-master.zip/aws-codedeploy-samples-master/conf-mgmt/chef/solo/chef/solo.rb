file_cache_path "/etc/chef/codedeploy/"
cookbook_path [
    "/etc/chef/codedeploy/cookbooks",
    "/etc/chef/codedeploy/site-cookbooks"
    ]
json_attribs "/etc/chef/codedeploy/node.json"
