APPLICATION_NAME="SaltMasterless"
DEPLOY_GROUP="Salt"
BUCKET="<bucket name>"
BUNDLE_PATH="salt-masterless.tar"
EC2_TAG_KEY='Salt'
EC2_TAG_VALUE='Masterless'

DESTINATION_PATH="/etc/salt/codedeploy"
